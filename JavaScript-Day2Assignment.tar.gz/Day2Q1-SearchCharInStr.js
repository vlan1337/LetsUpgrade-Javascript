let str = "LetsUpgrade";
console.log("The input string is: " + str);
console.log("Index of the character is : " + str.indexOf("s"));