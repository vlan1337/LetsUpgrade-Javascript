let arr = ["java","js","html","css","reactjs"];
for(var i=0;i<arr.length;i++) {
	if(arr[i]=="js") {
		console.log(arr[i]);
	}
}