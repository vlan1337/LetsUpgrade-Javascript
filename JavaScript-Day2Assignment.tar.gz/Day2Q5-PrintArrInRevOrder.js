let arr = ["java","js","html","css","reactjs"];
console.log("Original Order: " + arr.reverse());
console.log("Reverse Order: " + arr.reverse());