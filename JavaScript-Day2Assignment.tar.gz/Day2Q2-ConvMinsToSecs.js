var myTime = "01:30:33";
var arr = myTime.split(":");
var secs = (+arr[0]) * 60 * 60 + (+arr[1]) * 60 + (+arr[2]);
console.log(secs);